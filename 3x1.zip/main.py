import time
num1=int(input("enter number:")) 
loop_counter=0

def thr_x(num1,loop_counter):

 if num1==1.0:
   print("the number of loops is:",loop_counter)
   exit()
 
 if num1%2==0:
     num1=num1/2
     print(num1)
     loop_counter=loop_counter+1
     time.sleep(0.65)
     return thr_x(num1,loop_counter)
     
 if num1%2==1:
   num1=num1*3+1
   print(num1)
   loop_counter=loop_counter+1
   time.sleep(0.65)
   return thr_x(num1,loop_counter)
 
 

thr_x(num1,loop_counter)
